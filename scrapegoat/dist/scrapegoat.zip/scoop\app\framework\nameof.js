const nameof = (fn) => fn.name;
